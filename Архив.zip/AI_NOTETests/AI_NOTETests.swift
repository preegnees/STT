//
//  AI_NOTETests.swift
//  AI_NOTETests
//
//  Created by Радмир on 03.09.2025.
//

import Testing
@testable import AI_NOTE

struct AI_NOTETests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
