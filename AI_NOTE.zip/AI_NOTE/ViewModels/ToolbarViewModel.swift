//
//  TolbarViewModel.swift
//  AI_NOTE
//
//  Created by Радмир on 03.09.2025.
//

import SwiftUI
import CoreData

class TolbarViewModel: ObservableObject {
        
}
